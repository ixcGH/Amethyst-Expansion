
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.weaponry.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.Item;

import net.mcreator.weaponry.item.AmethystSwordItem;
import net.mcreator.weaponry.item.AmethystShovelItem;
import net.mcreator.weaponry.item.AmethystPickaxeItem;
import net.mcreator.weaponry.item.AmethystHoeItem;
import net.mcreator.weaponry.item.AmethystAxeItem;
import net.mcreator.weaponry.item.AmethystArmorItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class WeaponryModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item AMETHYST_ARMOR_HELMET = register(new AmethystArmorItem.Helmet());
	public static final Item AMETHYST_ARMOR_CHESTPLATE = register(new AmethystArmorItem.Chestplate());
	public static final Item AMETHYST_ARMOR_LEGGINGS = register(new AmethystArmorItem.Leggings());
	public static final Item AMETHYST_ARMOR_BOOTS = register(new AmethystArmorItem.Boots());
	public static final Item AMETHYST_PICKAXE = register(new AmethystPickaxeItem());
	public static final Item AMETHYST_AXE = register(new AmethystAxeItem());
	public static final Item AMETHYST_SWORD = register(new AmethystSwordItem());
	public static final Item AMETHYST_SHOVEL = register(new AmethystShovelItem());
	public static final Item AMETHYST_HOE = register(new AmethystHoeItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
